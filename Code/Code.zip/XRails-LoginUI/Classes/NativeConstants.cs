﻿namespace XRails.Classes
{
    internal class NativeConstants
    {
        internal const int IDC_HAND = 0x7F89;
        internal const int WM_SETCURSOR = 0x0020;
    }
}